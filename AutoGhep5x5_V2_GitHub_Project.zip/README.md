# AutoGhep5x5 V2

Bản V2 được chỉnh theo ảnh game người dùng cung cấp.

## Đã chỉnh quan trọng

1. Vùng mặc định theo ảnh mẫu:
   - X = 512
   - Y = 112
   - Width = 480
   - Height = 480
   - chia 5x5
2. Bỏ qua ô trung tâm (hàng 3, cột 3) vì đó là nút Rèn.
3. Khi tìm được cặp, app thực hiện **KÉO từ ô 1 sang ô 2** trong khoảng 420 ms.
4. Khi không còn cặp, app **giữ ô trung tâm 3 giây** rồi quét lại.
5. Matching ảnh dùng vùng trung tâm của từng ô, thu nhỏ 24x24 và yêu cầu score >= 90%.
6. Sau mỗi lần kéo, app chụp màn hình lại để tìm trạng thái mới, tránh dùng tọa độ cũ sau khi các vật liệu thay đổi.

## Theo ảnh mẫu

Lưới thực tế có 25 ô nhưng ô trung tâm là nút Rèn. Các vật liệu còn lại là:
- đá: xám, tím, vàng, đỏ
- bình: xanh, tím, vàng, đỏ

Các cặp trong ảnh mẫu cũng được nhìn thấy rõ, ví dụ bình đỏ ở hàng 1 cột 1 và hàng 1 cột 4; đá đỏ ở hàng 1 cột 2 và hàng 4 cột 5.

## Build

GitHub -> Actions -> Build AutoGhep5x5 APK -> Run workflow -> Artifacts -> AutoGhep5x5-debug -> app-debug.apk.

## Lưu ý

Tọa độ mặc định chỉ đúng gần với độ phân giải/scale của ảnh mẫu. Nếu điện thoại khác độ phân giải hoặc game dùng scale khác, cần chỉnh X/Y/Width/Height trong app.
