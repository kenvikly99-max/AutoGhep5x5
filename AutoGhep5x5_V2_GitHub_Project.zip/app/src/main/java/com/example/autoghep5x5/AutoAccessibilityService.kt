package com.example.autoghep5x5

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class AutoAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: AutoAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        stopAuto()
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAuto() }

    fun startAuto() {
        if (running.getAndSet(true)) return
        scanOnce()
    }

    fun stopAuto() {
        running.set(false)
        handler.removeCallbacksAndMessages(null)
    }

    private fun cfg(key: String, default: Long): Long =
        getSharedPreferences("cfg", MODE_PRIVATE).getLong(key, default)

    private fun scanOnce() {
        if (!running.get()) return

        takeScreenshot(object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val buffer = screenshot.hardwareBuffer
                val bitmap = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                buffer.close()

                if (bitmap == null) {
                    scheduleNext()
                    return
                }

                val bmp = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                bitmap.recycle()

                val x = cfg("x", 512).toInt()
                val y = cfg("y", 112).toInt()
                val w = cfg("w", 480).toInt()
                val h = cfg("h", 480).toInt()
                val threshold = cfg("threshold", 90).toInt()

                val pair = findBestPair(bmp, x, y, w, h, threshold)
                bmp.recycle()

                if (pair != null) {
                    // QUAN TRỌNG: game này ghép bằng KÉO từ ô 1 sang ô 2,
                    // không phải chạm ô 1 rồi chạm ô 2.
                    performDrag(pair.a, pair.b, x, y, w, h) {
                        handler.postDelayed({ scanOnce() }, cfg("delay", 250))
                    }
                } else {
                    // Không còn cặp: giữ ô trung tâm (hàng 3, cột 3) 3 giây.
                    holdCenter(x, y, w, h, cfg("hold", 3000)) {
                        handler.postDelayed({ scanOnce() }, cfg("delay", 250))
                    }
                }
            }

            override fun onFailure(errorCode: Int) {
                scheduleNext()
            }
        })
    }

    private fun scheduleNext() {
        if (running.get()) handler.postDelayed({ scanOnce() }, 500)
    }

    private data class PairPos(val a: Int, val b: Int, val score: Int)

    private fun findBestPair(
        screen: Bitmap, x: Int, y: Int, w: Int, h: Int, threshold: Int
    ): PairPos? {
        if (x < 0 || y < 0 || x + w > screen.width || y + h > screen.height) return null

        val cellW = w / 5
        val cellH = h / 5
        val crops = arrayOfNulls<Bitmap>(25)

        for (r in 0 until 5) for (c in 0 until 5) {
            val idx = r * 5 + c
            // Ô trung tâm là nút Rèn/giữ 3 giây, không phải vật liệu.
            if (idx == 12) continue
            val left = x + c * cellW
            val top = y + r * cellH
            crops[idx] = Bitmap.createBitmap(screen, left, top, cellW, cellH)
        }

        var best: PairPos? = null
        for (i in 0 until 25) {
            if (i == 12 || crops[i] == null || looksEmpty(crops[i]!!)) continue
            for (j in i + 1 until 25) {
                if (j == 12 || crops[j] == null || looksEmpty(crops[j]!!)) continue
                val score = similarity(crops[i]!!, crops[j]!!)
                if (score >= threshold && (best == null || score > best!!.score)) {
                    best = PairPos(i, j, score)
                }
            }
        }

        crops.forEach { it?.recycle() }
        return best
    }

    /*
     * Matching >90%:
     * - lấy vùng trung tâm của từng ô, bỏ 18% viền để giảm ảnh hưởng khung ô;
     * - thu nhỏ về 24x24;
     * - mỗi điểm ảnh được xem là "giống" nếu sai lệch RGB đủ nhỏ;
     * - score = số pixel giống / tổng pixel * 100.
     */
    private fun similarity(a: Bitmap, b: Bitmap): Int {
        val n = 24
        var same = 0
        var total = 0

        for (yy in 2 until n - 2) {
            for (xx in 2 until n - 2) {
                val pa = sampleInner(a, xx, yy, n)
                val pb = sampleInner(b, xx, yy, n)

                val dr = abs(((pa shr 16) and 255) - ((pb shr 16) and 255))
                val dg = abs(((pa shr 8) and 255) - ((pb shr 8) and 255))
                val db = abs((pa and 255) - (pb and 255))

                // 0..765. Ngưỡng 36 cho mỗi điểm để chịu được thay đổi nhỏ.
                if (dr + dg + db <= 55) same++
                total++
            }
        }
        return if (total == 0) 0 else same * 100 / total
    }

    private fun sampleInner(b: Bitmap, x: Int, y: Int, n: Int): Int {
        val marginX = (b.width * 0.18f).toInt()
        val marginY = (b.height * 0.18f).toInt()
        val usableW = max(1, b.width - 2 * marginX)
        val usableH = max(1, b.height - 2 * marginY)
        val px = min(b.width - 1, marginX + x * usableW / n)
        val py = min(b.height - 1, marginY + y * usableH / n)
        return b.getPixel(px, py)
    }

    private fun looksEmpty(b: Bitmap): Boolean {
        // Dùng độ tương phản + độ bão hòa để loại ô nền.
        var minV = 255
        var maxV = 0
        var satSum = 0
        var count = 0

        val sy = max(1, b.height / 16)
        val sx = max(1, b.width / 16)

        for (yy in b.height / 5 until b.height * 4 / 5 step sy) {
            for (xx in b.width / 5 until b.width * 4 / 5 step sx) {
                val p = b.getPixel(xx, yy)
                val r = p shr 16 and 255
                val g = p shr 8 and 255
                val bl = p and 255
                val v = (r + g + bl) / 3
                minV = min(minV, v)
                maxV = max(maxV, v)
                satSum += max(r, max(g, bl)) - min(r, min(g, bl))
                count++
            }
        }

        val contrast = maxV - minV
        val sat = if (count == 0) 0 else satSum / count

        // Đá xám vẫn có texture/contrast nên không loại chỉ vì saturation thấp.
        return contrast < 18 && sat < 12
    }

    private fun center(index: Int, x: Int, y: Int, w: Int, h: Int): Pair<Float, Float> {
        val cw = w / 5f
        val ch = h / 5f
        val row = index / 5
        val col = index % 5
        return Pair(x + (col + .5f) * cw, y + (row + .5f) * ch)
    }

    private fun performDrag(a: Int, b: Int, x: Int, y: Int, w: Int, h: Int, done: () -> Unit) {
        val p1 = center(a, x, y, w, h)
        val p2 = center(b, x, y, w, h)

        val path = Path().apply {
            moveTo(p1.first, p1.second)
            lineTo(p2.first, p2.second)
        }

        // Giả lập thao tác kéo: ACTION_DOWN -> di chuyển -> ACTION_UP.
        val stroke = GestureDescription.StrokeDescription(path, 0, 420)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                done()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                done()
            }
        }, null)
    }

    private fun holdCenter(x: Int, y: Int, w: Int, h: Int, duration: Long, done: () -> Unit) {
        val p = center(12, x, y, w, h)
        val path = Path().apply { moveTo(p.first, p.second) }
        val stroke = GestureDescription.StrokeDescription(path, 0, max(500, duration))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { done() }
        }, null)
    }
}
