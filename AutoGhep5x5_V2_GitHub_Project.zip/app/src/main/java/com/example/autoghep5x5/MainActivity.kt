package com.example.autoghep5x5

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.max

class MainActivity : android.app.Activity() {
    private lateinit var status: TextView
    private lateinit var x: EditText
    private lateinit var y: EditText
    private lateinit var w: EditText
    private lateinit var h: EditText
    private lateinit var threshold: EditText
    private lateinit var hold: EditText
    private lateinit var delay: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
        }

        val title = TextView(this).apply {
            text = "Auto Ghép 5x5"
            textSize = 26f
            setTextColor(Color.BLACK)
            setPadding(0,0,0,16)
        }
        root.addView(title)

        status = TextView(this).apply {
            text = "Trạng thái: chưa chạy"
            textSize = 16f
            setPadding(0,0,0,18)
        }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "Khu rèn 5x5 (tọa độ theo màn hình, px)"
            textSize = 18f
        })

        x = field(root, "X", "512")
        y = field(root, "Y", "112")
        w = field(root, "Chiều rộng", "480")
        h = field(root, "Chiều cao", "480")

        root.addView(TextView(this).apply {
            text = "Matching ảnh"
            textSize = 18f
            setPadding(0,16,0,0)
        })
        threshold = field(root, "Ngưỡng giống nhau (%)", "90")

        root.addView(TextView(this).apply {
            text = "Thời gian giữ ô trung tâm (ms)"
            textSize = 18f
            setPadding(0,8,0,0)
        })
        hold = field(root, "Giữ", "3000")
        delay = field(root, "Độ trễ giữa thao tác (ms)", "250")

        val save = Button(this).apply { text = "Lưu cấu hình" }
        save.setOnClickListener {
            saveConfig()
            Toast.makeText(this, "Đã lưu", Toast.LENGTH_SHORT).show()
        }
        root.addView(save)

        val access = Button(this).apply { text = "1. Mở quyền Trợ năng" }
        access.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.addView(access)

        val auto = Button(this).apply {
            text = "AUTO"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(0, 140, 70))
        }
        auto.setOnClickListener {
            saveConfig()
            val service = AutoAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this, "Hãy bật dịch vụ Trợ năng trước.", Toast.LENGTH_LONG).show()
            } else {
                service.startAuto()
                status.text = "Trạng thái: AUTO đang chạy"
            }
        }
        root.addView(auto)

        val stop = Button(this).apply {
            text = "STOP"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(190, 30, 30))
        }
        stop.setOnClickListener {
            AutoAccessibilityService.instance?.stopAuto()
            status.text = "Trạng thái: đã STOP"
        }
        root.addView(stop)

        val help = TextView(this).apply {
            text = "\nLưu ý: bản 1 dùng AccessibilityService để chụp màn hình và thao tác. Sau khi bật quyền Trợ năng, mở game, quay lại app cấu hình rồi bấm AUTO."
            textSize = 14f
        }
        root.addView(help)

        loadConfig()
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun field(parent: LinearLayout, label: String, value: String): EditText {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val tv = TextView(this).apply { text = "$label: "; textSize = 15f }
        wrap.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        val e = EditText(this).apply {
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSelectAllOnFocus(true)
        }
        wrap.addView(e, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(wrap)
        return e
    }

    private fun prefs() = getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun saveConfig() {
        prefs().edit()
            .putInt("x", x.text.toString().toIntOrNull() ?: 100)
            .putInt("y", y.text.toString().toIntOrNull() ?: 300)
            .putInt("w", w.text.toString().toIntOrNull() ?: 1000)
            .putInt("h", h.text.toString().toIntOrNull() ?: 1000)
            .putInt("threshold", max(50, threshold.text.toString().toIntOrNull() ?: 90))
            .putLong("hold", max(500, hold.text.toString().toLongOrNull() ?: 3000))
            .putLong("delay", max(50, delay.text.toString().toLongOrNull() ?: 250))
            .apply()
    }

    private fun loadConfig() {
        val p = prefs()
        x.setText(p.getInt("x",512).toString())
        y.setText(p.getInt("y",112).toString())
        w.setText(p.getInt("w",480).toString())
        h.setText(p.getInt("h",480).toString())
        threshold.setText(p.getInt("threshold",90).toString())
        hold.setText(p.getLong("hold",3000).toString())
        delay.setText(p.getLong("delay",250).toString())
    }
}
